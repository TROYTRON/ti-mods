﻿using BepInEx;
using HarmonyLib;
using PavonisInteractive.TerraInvicta;
using System;

namespace IncomePerTurn
{
	[BepInPlugin(PluginInfo.PLUGIN_GUID, PluginInfo.PLUGIN_NAME, PluginInfo.PLUGIN_VERSION)]
	[BepInProcess("TerraInvicta.exe")]
	public class Plugin : BaseUnityPlugin
	{
		private void Awake()
		{
			Logger.LogInfo($"Plugin {PluginInfo.PLUGIN_GUID} is loaded!");
			var harmony = new Harmony("Wolf_IncomePerTurn");
			harmony.PatchAll();
		}
	}

	[HarmonyPatch(typeof(GeneralControlsController))]
	[HarmonyPatch("ResourceReportString")]
	class PatchResourceReport
	{
		static bool Prefix(ref string __result, TIFactionState faction, FactionResource resourceType)
		{
			string result = string.Empty;

			switch (resourceType)
			{
				case FactionResource.Money:
				case FactionResource.Influence:
				case FactionResource.Operations:
				case FactionResource.Boost:
				case FactionResource.Water:
				case FactionResource.Volatiles:
				case FactionResource.Metals:
				case FactionResource.NobleMetals:
				case FactionResource.Fissiles:
				case FactionResource.Antimatter:
				case FactionResource.Exotics:
					{
						// The patch's main purpose is to add this x15 multiplier
						float num = faction.GetDailyIncome(resourceType) * 15f;

						float num2 = (float)Math.Truncate((double)faction.GetCurrentResourceAmount(resourceType));

						if (num == 0f)
						{
							result = TIUtilities.FormatBigNumber((double)num2, 1);
						}
						else if (num > 0f)
						{
							result = Loc.T("UI.GeneralControls.ResourcesGain", new object[]
							{
							TIUtilities.FormatBigNumber((double)num2, 1),
							Math.Truncate((double)num).ToString("N0")
							});
						}
						else if (num <= -1f)
						{
							result = Loc.T("UI.GeneralControls.ResourcesLoss", new object[]
							{
							TIUtilities.FormatBigNumber((double)num2, 1),
							Math.Truncate((double)num).ToString("N0")
							});
						}
						else
						{
							result = Loc.T("UI.GeneralControls.ResourcesSmallLoss", new object[]
							{
							TIUtilities.FormatBigNumber((double)num2, 1),
							"0"
							});
						}

						// Was a typical daily-ticked resource, so change the function result and disable the original function
						__result = result;
						return false;
					}
			}

			// Wasn't a typical resource, so the original function should run
			return true;
		}
	}
}
